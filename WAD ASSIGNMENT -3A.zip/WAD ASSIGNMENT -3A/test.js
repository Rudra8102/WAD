var express = require("express");
var app = express();
app.use(express.static("discord-server-list"));
app.listen(8081);
