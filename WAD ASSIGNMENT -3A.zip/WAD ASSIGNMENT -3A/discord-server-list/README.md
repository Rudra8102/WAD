# discord-server-list
My Discord Server List project, built as a college assignment.
